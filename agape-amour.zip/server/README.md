# AGAPE AMOUR Backend
Express.js API with MongoDB and OpenAI integration.
